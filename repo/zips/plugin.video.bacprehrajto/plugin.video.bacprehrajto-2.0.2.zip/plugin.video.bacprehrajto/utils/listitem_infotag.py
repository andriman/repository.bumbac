"""InfoTagVideo helpers with fallback to deprecated ListItem.setInfo / addStreamInfo."""
import json
from typing import Any, Dict, Optional

import xbmcgui

LISTING_STREAM_INFO_PROP = 'PrehrajListingStreamInfo'


def _video_tag(list_item: xbmcgui.ListItem):
    try:
        return list_item.getVideoInfoTag()
    except (AttributeError, RuntimeError):
        return None


def apply_video_stream_info(list_item: xbmcgui.ListItem, stream_info: Optional[Dict[str, Any]]) -> None:
    if not stream_info:
        return

    tag = _video_tag(list_item)
    if tag is not None:
        try:
            if hasattr(tag, 'addVideoStream'):
                tag.addVideoStream(dict(stream_info))
                return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

        try:
            mediatype = stream_info.get('mediatype')
            if mediatype is not None and hasattr(tag, 'setMediaType'):
                tag.setMediaType(str(mediatype))

            duration = stream_info.get('duration')
            if duration is not None and hasattr(tag, 'setDuration'):
                tag.setDuration(int(duration))

            size = stream_info.get('size')
            if size is not None:
                if hasattr(tag, 'setFileSize'):
                    tag.setFileSize(int(size))
                elif hasattr(tag, 'setSize'):
                    tag.setSize(int(size))

            width = stream_info.get('width')
            height = stream_info.get('height')
            if width is not None and hasattr(tag, 'setVideoWidth'):
                tag.setVideoWidth(int(width))
            if height is not None and hasattr(tag, 'setVideoHeight'):
                tag.setVideoHeight(int(height))

            codec = stream_info.get('codec')
            if codec is not None and hasattr(tag, 'setVideoCodec'):
                tag.setVideoCodec(str(codec))

            aspect = stream_info.get('aspect')
            if aspect is not None and hasattr(tag, 'setVideoAspect'):
                tag.setVideoAspect(float(aspect))
            return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    try:
        list_item.addStreamInfo('video', stream_info)
    except (AttributeError, RuntimeError, TypeError):
        pass


def apply_audio_stream_info(list_item: xbmcgui.ListItem, stream_info: Optional[Dict[str, Any]]) -> None:
    if not stream_info:
        return

    tag = _video_tag(list_item)
    if tag is not None:
        try:
            if hasattr(tag, 'addAudioStream'):
                tag.addAudioStream(dict(stream_info))
                return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    try:
        list_item.addStreamInfo('audio', stream_info)
    except (AttributeError, RuntimeError, TypeError):
        pass


def apply_video_info(list_item: xbmcgui.ListItem, info: Optional[Dict[str, Any]]) -> None:
    if not info:
        return

    tag = _video_tag(list_item)
    if tag is not None:
        try:
            _SETTERS = (
                ('title', 'setTitle'),
                ('plot', 'setPlot'),
                ('year', 'setYear'),
                ('premiered', 'setPremiered'),
                ('aired', 'setFirstAired'),
                ('firstaired', 'setFirstAired'),
                ('genre', 'setGenres'),
                ('rating', 'setRating'),
                ('imdbnumber', 'setIMDBNumber'),
                ('uniqueid', 'setUniqueID'),
                ('mediatype', 'setMediaType'),
                ('trailer', 'setTrailer'),
                ('duration', 'setDuration'),
                ('cast', 'setCast'),
                ('director', 'setDirectors'),
                ('writer', 'setWriters'),
                ('studio', 'setStudios'),
                ('country', 'setCountries'),
                ('tagline', 'setTagLine'),
                ('status', 'setTvShowStatus'),
            )
            for key, method_name in _SETTERS:
                if key not in info:
                    continue
                value = info.get(key)
                if value is None or value == '':
                    continue
                method = getattr(tag, method_name, None)
                if method is None:
                    continue
                if key == 'genre':
                    if isinstance(value, list):
                        method(value)
                    else:
                        method([str(value)])
                elif key == 'year':
                    try:
                        method(int(str(value).split('-')[0]))
                    except (ValueError, TypeError):
                        pass
                elif key == 'duration':
                    method(int(value))
                elif key == 'rating':
                    method(float(value))
                elif key in ('cast', 'director', 'writer', 'studio', 'country'):
                    if isinstance(value, list):
                        method(value)
                    else:
                        method([str(value)])
                else:
                    method(str(value))
            return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    try:
        list_item.setInfo('video', info)
    except (AttributeError, RuntimeError, TypeError):
        pass


def attach_listing_stream_info_property(list_item: xbmcgui.ListItem, stream_info: Dict[str, Any]) -> None:
    """Store stream metadata for deferred apply at directory render (fast scrape)."""
    if stream_info:
        list_item.setProperty(LISTING_STREAM_INFO_PROP, json.dumps(stream_info))


def stream_info_from_listing_property(list_item: xbmcgui.ListItem) -> Optional[Dict[str, Any]]:
    raw = (list_item.getProperty(LISTING_STREAM_INFO_PROP) or '').strip()
    if not raw:
        return None
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def apply_deferred_listing_stream_info(list_item: xbmcgui.ListItem) -> None:
    """Apply stream metadata stored on the item during scrape (property only)."""
    stream_info = stream_info_from_listing_property(list_item)
    if stream_info:
        apply_video_stream_info(list_item, stream_info)
