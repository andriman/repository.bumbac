import xbmcgui

from common import COLOR_LIST_MUTED, SEARCH_SOURCE_NO_RESULTS_PROP

PROVIDER_LABEL_PREHRAJTO = 'Prehraj.to'
PROVIDER_LABEL_SLEDUJTETO = 'Sledujteto.cz'


def make_source_no_results_item(provider_label: str) -> xbmcgui.ListItem:
    """Non-playable gray row when an enabled source returned no videos."""
    label = f'[COLOR {COLOR_LIST_MUTED}]{provider_label}: No results[/COLOR]'
    item = xbmcgui.ListItem(label=label, path='', offscreen=True)
    item.setProperty('IsPlayable', 'false')
    item.setProperty(SEARCH_SOURCE_NO_RESULTS_PROP, 'true')
    return item


def is_source_no_results_item(item: xbmcgui.ListItem) -> bool:
    return item.getProperty(SEARCH_SOURCE_NO_RESULTS_PROP) == 'true'
