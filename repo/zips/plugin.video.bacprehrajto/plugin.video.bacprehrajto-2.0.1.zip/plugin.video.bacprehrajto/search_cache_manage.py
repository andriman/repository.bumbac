# -*- coding: utf-8 -*-
"""Clear search result disk cache (invoked from add-on settings)."""

import sys

import xbmcgui

from cache.search_cache import (
    clear_search_cache,
    format_search_cache_size_label,
    refresh_search_cache_setting,
)
from common import _ADDON_NAME
from utils.StrUtils import convert_size


def _notify(heading: str, message: str, icon=xbmcgui.NOTIFICATION_INFO) -> None:
    xbmcgui.Dialog().notification(heading, message, icon, 4000, sound=False)


def _run_clear() -> None:
    current = format_search_cache_size_label()
    if not xbmcgui.Dialog().yesno(
            _ADDON_NAME,
            f'Smazat cache hledání?\n\nAktuální velikost: {current}',
            nolabel='Ne',
            yeslabel='Ano',
    ):
        return

    removed, freed = clear_search_cache()
    refresh_search_cache_setting()
    if removed == 0:
        _notify(_ADDON_NAME, 'Cache hledání je již prázdná')
        return
    _notify(
        _ADDON_NAME,
        f'Smazáno {removed} souborů ({convert_size(freed, 1)})',
    )


if __name__ == '__main__':
    mode = (sys.argv[1] if len(sys.argv) > 1 else 'clear').strip().lower()
    if mode == 'clear':
        _run_clear()
