import json
from datetime import datetime
from typing import Dict, Tuple
from urllib.parse import quote, urlencode
from urllib.request import urlopen

import xbmc
import xbmcgui
import xbmcplugin

from tmdb.tmdb_language import get_tmdb_api_language
from utils.listitem_infotag import apply_video_info
from utils.utils import dprint, get_url

TMDB_API_KEY = '1f0150a5f78d4adc2407911989fdb66c'

_gid_fallback = {
    28: "Akční", 12: "Dobrodružný", 16: "Animovaný", 35: "Komedie", 80: "Krimi", 99: "Dokumentární",
    18: "Drama", 10751: "Rodinný", 14: "Fantasy", 36: "Historický", 27: "Horor", 10402: "Hudební",
    9648: "Mysteriózní", 10749: "Romantický", 878: "Vědeckofantastický", 10770: "Televizní film",
    53: "Thriller", 10752: "Válečný", 37: "Western", 10759: "Action & Adventure", 10762: "Kids",
    10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy", 10766: "Soap", 10767: "Talk",
    10768: "War & Politics",
}

_genre_cache: Dict[Tuple[str, str], Dict[int, str]] = {}


def _tmdb_fetch(path: str, **params) -> dict:
    query = dict(params)
    query['api_key'] = TMDB_API_KEY
    query['language'] = get_tmdb_api_language()
    url = f'https://api.themoviedb.org/3/{path}?{urlencode(query)}'
    dprint(f'tmdb fetch: {url}')
    return json.loads(urlopen(url).read())


def _load_genre_map(media_type: str) -> Dict[int, str]:
    api_lang = get_tmdb_api_language()
    key = (media_type, api_lang)
    if key in _genre_cache:
        return _genre_cache[key]
    res = _tmdb_fetch(f'genre/{media_type}/list')
    genre_map = {g['id']: g['name'] for g in res.get('genres', []) if g.get('id') is not None}
    _genre_cache[key] = genre_map
    return genre_map


def get_tmdb_genre_name(genre_id: int, media_type: str) -> str:
    genre_map = _load_genre_map(media_type)
    if genre_id in genre_map:
        return genre_map[genre_id]
    return _gid_fallback.get(genre_id, str(genre_id))


def _genre_string(genre_ids, media_type: str) -> str:
    return ' / '.join(get_tmdb_genre_name(g, media_type) for g in genre_ids)


def tmdb_episodes(_handle, _url, sname, params):
    type = params["type"]
    ses_num = params["ses_num"]
    fanart = params.get("fanart", "")
    thumb = params.get("thumb", "")

    dprint(f'sname(): ' + sname)

    res = _tmdb_fetch(f'tv/{type}/season/{ses_num}')

    for category in res['episodes']:
        if not category['name']:
            category['name'] = "Neznámo"
        if category['name'] != 'Speciály' and category['name'] != 'Specials':
            epNo = 'E' + str(category['episode_number'])

            air_date = category.get('air_date') or ''
            air_year = air_date.split('-')[0] if air_date else ''
            date_label2 = f"Datum vysílání: {air_date}" if air_date else ''

            list_item = xbmcgui.ListItem(label=epNo + ': ' + category['name'], label2=date_label2)

            plot = category['overview']
            if plot == "":
                plot = "~ empty ~"

            directors = [
                member['name'] for member in category.get('crew', [])
                if member.get('job') == 'Director'
            ]

            castandrole = [
                (star['name'], star['character'])
                for star in category.get('guest_stars', [])[:20]
                if star.get('name') and star.get('character')
            ]
            extended_plot = plot
            if air_date:
                extended_plot = f"Datum vysílání: {air_date}\n\n" + extended_plot
                plot = f"Datum vysílání: {air_date}\n\n" + plot

            if directors:
                extended_plot += f"\n\nDirectors: {', '.join(directors)}"

            videoInfo = {
                'title': category['name'],
                'plot': extended_plot,
                'plotoutline': plot,
                'year': air_year,
                'rating': category["vote_average"],
                'castandrole': castandrole,
                'premiered': air_date,
                'aired': air_date,
                'episode': category.get('episode_number', 0),
                'status': category.get('status', 'Released')
            }

            art = {'thumb': thumb, 'icon': thumb, 'fanart': fanart}

            apply_video_info(list_item, videoInfo)
            list_item.setArt(art)

            full_name = sname + ' S' + str(category['season_number']).zfill(2) + 'E' + str(
                category['episode_number']).zfill(2)
            url = get_url(_url, action='listing_search', name=full_name, type=type, videoInfo=json.dumps(videoInfo),
                          art=json.dumps(art))
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_seasons(_handle, _url, name, type):
    res = _tmdb_fetch(f'tv/{type}')
    dprint(f'tmdb_seasons(): ' + str(res))
    try:
        fanart = "https://image.tmdb.org/t/p/w1280" + res["backdrop_path"]
    except Exception:
        fanart = ""
    for category in res['seasons']:
        if category['name'] != 'Speciály' and category['name'] != 'Specials':
            list_item = xbmcgui.ListItem(label=category['name'])
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})

            plot = category['overview']
            if plot == "":
                plot = "~ empty ~"

            apply_video_info(list_item, {
                'title': category['name'],
                'plot': plot,
                'plotoutline': plot,
                'year': category['air_date'],
                'rating': category["vote_average"],
            })

            url = get_url(_url, action='listing_episodes', name=name, type=type, ses_num=str(category['season_number']),
                          fanart=fanart, thumb=thumb)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)

    xbmcplugin.endOfDirectory(_handle)


def tmdb_serie(_handle, _url, page, type):
    p = int(page)
    res = _tmdb_fetch(f'tv/{type}', page=str(p))
    dprint(f'tmdb_serie(): ' + str(res))

    res["results"].append({"name": "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['name'])
        if category['name'] == "Další":
            url = get_url(_url, action='listing_tmdb_serie', name=str(p + 1), type=type)
        else:
            genre = _genre_string(category["genre_ids"], 'tv')
            apply_video_info(list_item, {'mediatype': 'movie', 'title': category['name'], "plot": category['overview'],
                                        "year": category['first_air_date'].split('-')[0], 'genre': genre,
                                        'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
            url = get_url(_url, action='listing_seasons', name=category['name'], type=category["id"])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_movie(_handle, _url, page, type):
    dprint("tmdb_movie()")

    p = int(page)
    res = _tmdb_fetch(f'movie/{type}', page=str(p))
    res["results"].append({"title": "Další"})
    res["results"].append({"title": "Domů"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['title'])
        if category['title'] == "Další":
            url = get_url(_url, action='listing_tmdb_movie', name=str(p + 1), type=type)
        elif category['title'] == "Domů":
            url = get_url(_url, action='home', name=str(p + 1), type=type)
        else:
            genre = _genre_string(category["genre_ids"], 'movie')
            try:
                year = category['release_date'].split('-')[0]
            except Exception:
                year = ''

            plot = category['overview']
            if plot == "":
                plot = "~ empty ~"

            directors = [
                member['name'] for member in category.get('crew', [])
                if member.get('job') == 'Director'
            ]

            main_cast = []
            for actor in category.get('guest_stars', [])[:10]:
                main_cast.append({
                    'name': actor.get('name', ''),
                    'role': actor.get('character', ''),
                    'thumbnail': f"https://image.tmdb.org/t/p/original{actor.get('profile_path', '')}" if actor.get(
                        'profile_path') else ''
                })

            extended_plot = plot
            if directors:
                extended_plot += f"\n\nDirectors: {', '.join(directors)}"

            videoInfo = {
                'mediatype': 'movie',
                'title': category['title'],
                'genre': genre,
                'plot': extended_plot,
                'plotoutline': plot,
                'year': year,
                'rating': category["vote_average"],
                'director': directors,
                'cast': main_cast,
                'writer': [
                    member['name'] for member in category.get('crew', [])
                    if member.get('job') == 'Writer'
                ],
                'premiered': category.get('air_date', ''),
                'episode': category.get('episode_number', 0),
                'status': category.get('status', 'Released')
            }

            apply_video_info(list_item, videoInfo)

            dprint("tmdb_movie(): " + str(category))
            dprint("tmdb_movie(): " + str(videoInfo))

            if main_cast:
                dprint("tmdb_movie cast(): " + str(main_cast))
                list_item.setCast(main_cast)

            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""

            art = {'thumb': thumb, 'icon': thumb, 'fanart': fanart}

            list_item.setArt(art)
            url = get_url(
                _url,
                action='listing_search',
                name=category['title'] + " " + year,
                type=type,
                videoInfo=json.dumps(videoInfo),
                art=json.dumps(art)
            )
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_serie_genre(_handle, _url, page, type, id):
    p = int(page)
    res = _tmdb_fetch(f'discover/{type}', with_genres=id, page=str(p))
    res["results"].append({"name": "Další"})
    res["results"].append({"name": "Domů"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['name'])
        if category['name'] == "Další":
            url = get_url(_url, action='listing_genre', id=id, type=type, page=str(p + 1))
        elif category['name'] == "Domů":
            url = get_url(_url, action='home', id=id, type=type, page=str(p + 1))
        else:
            genre = _genre_string(category["genre_ids"], type)
            try:
                year = category['first_air_date'].split('-')[0]
            except Exception:
                year = ''
            apply_video_info(list_item, {'mediatype': 'movie', 'title': category['name'], "plot": category['overview'],
                                        "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
            url = get_url(_url, action='listing_seasons', name=category['name'], type=category["id"])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_movie_genre(_handle, _url, page, type, id):
    p = int(page)
    res = _tmdb_fetch(f'discover/{type}', with_genres=id, page=str(p))
    res["results"].append({"title": "Další"})
    res["results"].append({"title": "Domů"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['title'])
        if category['title'] == "Další":
            url = get_url(_url, action='listing_genre', id=id, type=type, page=str(p + 1))
        elif category['title'] == "Domů":
            url = get_url(_url, action='home', id=id, type=type, page=str(p + 1))
        else:
            genre = _genre_string(category["genre_ids"], type)
            try:
                year = category['release_date'].split('-')[0]
            except Exception:
                year = ''

            plot = category['overview']
            if plot == "":
                plot = "~ empty ~"

            videoInfo = {
                'mediatype': 'movie',
                'title': category['title'],
                'genre': genre,
                'plot': plot,
                'plotoutline': plot,
                'year': year,
                'rating': category["vote_average"],
            }

            apply_video_info(list_item, videoInfo)

            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""

            art = {'thumb': thumb, 'icon': thumb, 'fanart': fanart}

            list_item.setArt(art)
            url = get_url(
                _url,
                action='listing_search',
                name=category['title'] + " " + year,
                type=type,
                videoInfo=json.dumps(videoInfo),
                art=json.dumps(art)
            )

        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def genres_category(_handle, _url, type):
    res = _tmdb_fetch(f'genre/{type}/list')
    for category in res['genres']:
        list_item = xbmcgui.ListItem(label=category['name'])
        url = get_url(_url, action='listing_genre', id=str(category['id']), type=type, page='1')
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_year(_handle, _url, page, type, id):
    if type == 'movie':
        title = 'title'
        rd = 'release_date'
        fy = 'primary_release_year'
    else:
        title = 'name'
        rd = 'first_air_date'
        fy = 'first_air_date_year'
    p = int(page)
    res = _tmdb_fetch(f'discover/{type}', **{fy: id}, page=str(p))
    res["results"].append({title: "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category[title])
        if category[title] == "Další":
            url = get_url(_url, action='listing_year', id=id, type=type, page=str(p + 1))
        else:
            genre = _genre_string(category["genre_ids"], type)
            try:
                year = category[rd].split('-')[0]
            except Exception:
                year = ''

            plot = category['overview']
            if plot == "":
                plot = "~ empty ~"

            dprint("tmdb_year: " + str(category))
            videoInfo = {
                'mediatype': 'movie',
                'title': category.get('name', category.get('title', '#ERROR#')),
                'genre': genre,
                'plot': plot,
                'plotoutline': plot,
                'year': year,
                'rating': category["vote_average"],
            }
            apply_video_info(list_item, videoInfo)

            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""

            art = {'thumb': thumb, 'icon': thumb, 'fanart': fanart}
            list_item.setArt(art)

            if type == 'movie':
                url = get_url(
                    _url,
                    action='listing_search',
                    name=category['title'] + " " + year,
                    type=type,
                    videoInfo=json.dumps(videoInfo),
                    art=json.dumps(art)
                )
            else:
                url = get_url(_url, action='listing_seasons', name=category[title], type=category["id"])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def years_category(_handle, _url, type):
    year = datetime.today().year
    YEARS = [year - i for i in range(101)]
    for category in YEARS:
        list_item = xbmcgui.ListItem(label=str(category))
        url = get_url(_url, action='listing_year', type=type, id=str(category), page='1')
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def search_tmdb(_handle, _url, name, type):
    if name == "movie":
        stitle = "filmu"
    else:
        stitle = "seriálu"
    kb = xbmc.Keyboard("", 'Zadejte název ' + stitle)
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText()
    if q == "":
        return
    res = _tmdb_fetch(f'search/{name}', page='1', include_adult='false', query=q)
    xbmcplugin.setContent(_handle, 'videos')

    media_type = name if name in ('movie', 'tv') else 'movie'

    if name == "movie":
        for category in res['results']:
            list_item = xbmcgui.ListItem(label=category['title'])
            genre = _genre_string(category["genre_ids"], media_type)
            try:
                year = category['release_date'].split('-')[0]
            except Exception:
                year = ''
            apply_video_info(list_item, {'mediatype': 'movie', 'title': category['title'], "plot": category['overview'],
                                        "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
            url = get_url(_url, action='listing_search', name=category['title'] + " " + year, type=type)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    else:
        for category in res['results']:
            list_item = xbmcgui.ListItem(label=category['name'])
            genre = _genre_string(category["genre_ids"], 'tv')
            try:
                year = category['first_air_date'].split('-')[0]
            except Exception:
                year = ''
            apply_video_info(list_item, {'mediatype': 'movie', 'title': category['name'], "plot": category['overview'],
                                        "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except Exception:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except Exception:
                thumb = ""
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
            url = get_url(_url, action='listing_seasons', name=category['name'], type=category["id"])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def movie_category(_handle, _url):
    name_list = [("Nejlépe hodnocené", "listing_tmdb_movie", "1", "top_rated"),
                 ("Oblíbené", "listing_tmdb_movie", "1", "popular"), ("Novinky", "listing_tmdb_movie", "1", "upcoming"),
                 ("Žánry", "listing_genre_category", "movie", ""), ("Rok", "listing_year_category", "movie", ""),
                 ("Hledat", "search_tmdb", "movie", "1")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(_url, action=category[1], name=category[2], type=category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def serie_category(_handle, _url):
    name_list = [("Nejlépe hodnocené", "listing_tmdb_serie", "1", "top_rated"),
                 ("Oblíbené", "listing_tmdb_serie", "1", "popular"),
                 ("Vysílané", "listing_tmdb_serie", "1", "on_the_air"), ("Žánry", "listing_genre_category", "tv", ""),
                 ("Rok", "listing_year_category", "tv", ""), ("Hledat", "search_tmdb", "tv", "1")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(_url, action=category[1], name=category[2], type=category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)
