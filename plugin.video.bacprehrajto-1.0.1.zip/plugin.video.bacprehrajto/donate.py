# -*- coding: utf-8 -*-

import xbmc

# TODO.
qr_address = ''
xbmc.executebuiltin('ShowPicture('+qr_address+')')